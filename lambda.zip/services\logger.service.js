"use strict";
// ─────────────────────────────────────────────────────
// LOGGER SERVICE
// OOP concept: Encapsulation
// All logging logic hidden inside this class
// Handler just calls logger.info() — doesn't
// know HOW logging works internally
// ─────────────────────────────────────────────────────
Object.defineProperty(exports, "__esModule", { value: true });
exports.Logger = exports.LogLevel = void 0;
var LogLevel;
(function (LogLevel) {
    LogLevel["INFO"] = "INFO";
    LogLevel["WARN"] = "WARN";
    LogLevel["ERROR"] = "ERROR";
    LogLevel["DEBUG"] = "DEBUG";
})(LogLevel || (exports.LogLevel = LogLevel = {}));
class Logger {
    // Constructor — initialise with service name
    constructor(serviceName) {
        this.serviceName = serviceName;
    }
    // Private method — internal implementation hidden
    log(level, message, data) {
        const logEntry = {
            timestamp: new Date().toISOString(),
            level,
            service: this.serviceName,
            message,
            ...(data && { data }), // spread data only if provided
        };
        // CloudWatch captures console.log automatically
        if (level === LogLevel.ERROR) {
            console.error(JSON.stringify(logEntry));
        }
        else {
            console.log(JSON.stringify(logEntry));
        }
    }
    // Public methods — what the outside world can call
    info(message, data) {
        this.log(LogLevel.INFO, message, data);
    }
    warn(message, data) {
        this.log(LogLevel.WARN, message, data);
    }
    error(message, data) {
        this.log(LogLevel.ERROR, message, data);
    }
    debug(message, data) {
        if (process.env.NODE_ENV !== 'production') {
            this.log(LogLevel.DEBUG, message, data);
        }
    }
}
exports.Logger = Logger;
