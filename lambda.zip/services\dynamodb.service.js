"use strict";
// ─────────────────────────────────────────────────────
// DYNAMODB SERVICE
// OOP concept: Encapsulation + Single Responsibility
// All DynamoDB logic hidden inside this class
// Handler never touches DynamoDB directly
// ─────────────────────────────────────────────────────
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDBService = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const util_dynamodb_1 = require("@aws-sdk/util-dynamodb");
// Initialise OUTSIDE class — cached between Lambda invocations
// This is a performance optimisation — not creating new
// client on every request
const dynamoClient = new client_dynamodb_1.DynamoDBClient({
    region: process.env.AWS_REGION || 'ap-south-1',
});
class DynamoDBService {
    // Constructor — dependency injection
    // Logger is INJECTED — not created inside
    // Makes testing easier — can inject mock logger
    constructor(logger) {
        this.tableName = process.env.TABLE_NAME || 'growmoney-calculations';
        this.logger = logger;
    }
    // ── SAVE CALCULATION ─────────────────────────────
    async saveCalculation(calculation) {
        try {
            this.logger.info('Saving calculation to DynamoDB', {
                calculationId: calculation.calculationId,
            });
            await dynamoClient.send(new client_dynamodb_1.PutItemCommand({
                TableName: this.tableName,
                Item: (0, util_dynamodb_1.marshall)(calculation, {
                    removeUndefinedValues: true, // skip undefined optional fields
                }),
                // Prevent overwriting existing item
                ConditionExpression: 'attribute_not_exists(calculationId)',
            }));
            this.logger.info('Calculation saved successfully', {
                calculationId: calculation.calculationId,
            });
        }
        catch (error) {
            this.logger.error('Failed to save calculation', {
                error: error instanceof Error ? error.message : 'Unknown error',
                calculationId: calculation.calculationId,
            });
            throw error;
        }
    }
    // ── GET TOTAL COUNT ───────────────────────────────
    async getTotalCount() {
        try {
            const result = await dynamoClient.send(new client_dynamodb_1.ScanCommand({
                TableName: this.tableName,
                Select: 'COUNT', // only return count — not all items
            }));
            return result.Count || 0;
        }
        catch (error) {
            this.logger.error('Failed to get count', {
                error: error instanceof Error ? error.message : 'Unknown error',
            });
            return 0; // return 0 on error — non-critical
        }
    }
}
exports.DynamoDBService = DynamoDBService;
