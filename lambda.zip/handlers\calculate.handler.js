"use strict";
// ─────────────────────────────────────────────────────
// LAMBDA HANDLER — entry point
// OOP concept: Dependency Injection
// Services are created here and injected
// Handler orchestrates — does not implement logic
// ─────────────────────────────────────────────────────
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const uuid_1 = require("uuid");
const logger_service_1 = require("../services/logger.service");
const sip_service_1 = require("../services/sip.service");
const dynamodb_service_1 = require("../services/dynamodb.service");
const validator_1 = require("../utils/validator");
// ── INITIALISE OUTSIDE HANDLER ────────────────────
// Cached between Lambda invocations (warm starts)
// This is a performance best practice
const logger = new logger_service_1.Logger('CalculateHandler');
const sipService = new sip_service_1.SIPService();
const dbService = new dynamodb_service_1.DynamoDBService(logger);
// ── CORS HEADERS ──────────────────────────────────
// Required for browser to accept response
const corsHeaders = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
};
// ── MAIN HANDLER ──────────────────────────────────
const handler = async (event) => {
    const requestId = event.requestContext.requestId;
    const method = event.requestContext.http.method;
    const path = event.requestContext.http.path;
    logger.info('Request received', { requestId, method, path });
    // Handle CORS preflight
    if (method === 'OPTIONS') {
        return { statusCode: 200, headers: corsHeaders, body: '' };
    }
    try {
        // ── POST /calculate ──────────────────────────
        if (method === 'POST' && path === '/calculate') {
            return await handleCalculate(event);
        }
        // ── GET /stats ───────────────────────────────
        if (method === 'GET' && path === '/stats') {
            return await handleStats();
        }
        // ── 404 ──────────────────────────────────────
        return response(404, {
            success: false,
            error: 'Route not found',
        });
    }
    catch (error) {
        logger.error('Unhandled error in handler', {
            error: error instanceof Error ? error.message : 'Unknown error',
            requestId,
        });
        return response(500, {
            success: false,
            error: 'Internal server error',
        });
    }
};
exports.handler = handler;
// ── CALCULATE HANDLER ─────────────────────────────
async function handleCalculate(event) {
    // Parse body
    let body;
    try {
        body = JSON.parse(event.body || '{}');
    }
    catch {
        return response(400, {
            success: false,
            error: 'Invalid JSON in request body',
        });
    }
    // Validate input
    const validation = (0, validator_1.validateCalculationInput)(body);
    if (!validation.isValid) {
        return response(400, {
            success: false,
            error: 'Validation failed',
            data: validation.errors,
        });
    }
    const input = body;
    // Calculate SIP
    const result = sipService.calculate(input);
    // Build calculation record for DynamoDB
    const calculationId = `CALC-${(0, uuid_1.v4)()}`;
    const now = new Date();
    const oneYearLater = Math.floor(now.getTime() / 1000) + (365 * 24 * 60 * 60);
    const calculation = {
        calculationId,
        monthly: input.monthly,
        rate: input.rate,
        years: input.years,
        invested: result.invested,
        returns: result.returns,
        maturity: result.maturity,
        name: input.name,
        email: input.email,
        ipAddress: event.requestContext.http.sourceIp,
        userAgent: event.requestContext.http.userAgent,
        timestamp: now.toISOString(),
        expiresAt: oneYearLater, // TTL — auto delete after 1 year
    };
    // Save to DynamoDB (non-blocking to result)
    // We don't await here so response is faster
    // If DB save fails — user still gets their result
    dbService.saveCalculation(calculation).catch((error) => {
        logger.error('Background DB save failed', {
            calculationId,
            error: error instanceof Error ? error.message : 'Unknown',
        });
    });
    logger.info('Calculation completed', {
        calculationId,
        maturity: result.maturity,
    });
    // Return result to user
    return response(200, {
        success: true,
        data: {
            calculationId,
            ...result,
        },
    });
}
// ── STATS HANDLER ─────────────────────────────────
async function handleStats() {
    const count = await dbService.getTotalCount();
    return response(200, {
        success: true,
        data: {
            totalCalculations: count,
            message: `${count.toLocaleString('en-IN')}+ calculations done`,
        },
    });
}
// ── RESPONSE HELPER ───────────────────────────────
function response(statusCode, body) {
    return {
        statusCode,
        headers: corsHeaders,
        body: JSON.stringify(body),
    };
}
