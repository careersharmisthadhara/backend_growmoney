"use strict";
// ─────────────────────────────────────────────────────
// INTERFACES — define the shape of our data
// This is TypeScript OOP — interfaces as contracts
// ─────────────────────────────────────────────────────
Object.defineProperty(exports, "__esModule", { value: true });
